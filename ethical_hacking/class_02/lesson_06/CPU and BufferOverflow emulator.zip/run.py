""""
This is the main program file to run
The point of the program is
1) emulate a very basic CPU to show how CPUs work, based on the CardiacCPU (cardboard computer)
2) allow a opportunity to simulate, experiment, and observe with a buffer overflow in this emulated CPU

any comments which look like this
# >>>>> do something <<<<<<
shows where the code file is meant for you to modify, interact with, and rerun. go observe the difference in behavior and do some experimentation

By: Jason Tsang Mui Chung
This script was written in python version 3.7.9, as such run it using python3
"""
import os
import sys
from CardiacCPU import Cardiac
from visual_explanation import Printer 
from Suppliment_LogicalGatesAndBoolean_Explanation import Gates
from Suppliment_BinaryMath_Explanation import binarymath
#===============================================================================
# All CPUs have four main functions:
# 
#     Fetch 
#        - receives instruction(or set of) for CPU. 
#        - instructions are from the RAM, in form of binary numbers (1s and 0s)
#        - each instruction is a small building block of a larger "operation". CPU needs to know the order of instructions.
#        - what instructions at what address
#     Decode
#        - after fetch, instruction stored in instruction register, then instruction is "decoded".
#        - passes instruction to circuit "instruction decoder"
#        - instruction decoder turn instruction into a set of signals, which goes to different parts of the CPU
#     Execute
#        - after decoded and signals sent to respective parts of cpu
#        - small instructions/signals are "executed", produce outputs, then stored in CPU "register"
#        - other instructions after can reference output in registers 
#        - it does not need to be referenced, sent to the RAM or the hard drive for storage (or other outputs like speakers, display, etc)
#     Store
#        - CPU sends restults to RAM or the hard drive for storage
#        - can store data temporarily in registers, only data needed for what is currently executing
#
# "instructions" > machine language (e.g: assembly), instruction set commands processor to do simple activities with data
#    ADD - Add two numbers together.
#    COMPARE - Compare numbers.
#    IN - Input information from a device, e.g., keyboard.
#    JUMP - Jump to designated RAM address.
#    JUMP IF - Conditional statement that jumps to a designated RAM address.
#    LOAD - Load information from RAM to the CPU.
#    OUT - Output information to device, e.g., monitor.
#    STORE - Store information to RAM.
#
# "registers" > location where data CPU is actively working is located, different from say ram or disk
#    CPU design is only able modify, act on, data when it is in a register
#
# "accumulator" >  accumulator is a register in which intermediate arithmetic and logic results are stored
#
# "program counter" > aka instruction pointer, aka instruction address register, aka instruction counter, aka instruction sequencer
#    cpu/processor register that indicates where a computer is in its program sequence
#    >>points to memory location which data needs to be fetched from next<<
#    >>intent/counter gets incremented by 1, from each step to the next<<
#    e.g: (step2) Instruction Register: 800 -> Program Counter (pointer): 000 -> Accumulator: 0
#    e.g: (step3) Instruction Register: 001 -> Program Counter (pointer): 001 -> Accumulator: 0
#        instruction "800" -> 
#         |OpCode|  Address  |
#         | 100s | 10s |  1s |
#         |  8   |  0  |  0  |
#        from step 2 -> 3 
#         (step2) Opcode = 8, address = 00
#         (step3) Opcode = [load what is in "00"], address = [00 + 1 = 01]
#===============================================================================

prerequisite_tutorial = True #>>>>> Set this to false once finishied understanding logical gates and boolean math <<<<<<<
#===============================================================================
# What are logical gates? Operations like "OR" "AND" etc?
#===============================================================================
if(prerequisite_tutorial):
    print("\n===prerequisite_tutorial - Logical Gates ===========================")# Leave this alone
    a = 1           # >>>>> Modify this Value, change it to '0' or '1' to see different outcomes and rerun this file <<<<<<<
    b = 0           # >>>>> Modify this Value, change it to '0' or '1' to see different outcomes and rerun this file <<<<<<<
    Gates.AND(a, b) # Leave this alone
    Gates.OR(a, b)  # Leave this alone

#===============================================================================
# How do you do math in binary?
#===============================================================================
if(prerequisite_tutorial):
    print("\n===prerequisite_tutorial - Binary Math +===========================")# Leave this alone
    input1 = "1101" # >>>>> Modify this Value, change it to various binary strings, 1s and 0s to see what effect it has, then rerun this file <<<<<<<
    input2 = "101"  # >>>>> Modify this Value, change it to various binary strings, 1s and 0s to see what effect it has, then rerun this file <<<<<<<
    binarymath.Add(input1,input2) # Leave this alone

#===============================================================================
# Run the CPU code!
# In this example we will use the Cadiac CPU, the cardboard computer
#===============================================================================
if(prerequisite_tutorial == False): # Leave this alone, only start the main turtorial/program once the prereqs are done
    c = Cardiac()           # Leave this alone
    c.init_cpu()            # Leave this alone
    c.reset()               # Leave this alone, resets the CPU's registers to their defaults.
    c.init_mem()            # Leave this alone, this is our memory (dependingon arcitecture our registers) 
    """!!!! - Setup the "Stack"- !!!!
    stack is a list of data words. 
    It uses Last In First Out (LIFO) access method which is the most popular access method in most of the CPU. 
    A register is used to store the address of the topmost element of the stack which is known as Stack pointer (SP). 
    In this organisation, ALU operations are performed on stack data. It means both the operands are always required on the stack. 
    After manipulation, the result is placed in the stack."""
    c.init_reader()         # Leave this alone, this is our "stack"
    Printer.print_stack(c)  # Leave this alone, simply to print helpful messages >>>>>to turn off view "visual_explantion.py"<<<<<
    #-------------------------------------------------------------------------------
    c.init_output()         # Leave this alone, output deck/paper/printer/teletype/etc...
    c.read_deck(os.path.join(sys.path[0], "cpu_input.txt")) # Leave this alone, insert instructions into stack, default setup for instruction to count to 10
    Printer.print_stack(c)  # Leave this alone, simply to print helpful messages >>>>>to turn off view "visual_explantion.py"<<<<<
    #=======================================================================
    # Here we can introduce/mimic a buffer overflow
    #=======================================================================
    # >>>>> Set to True/False to enable buffer overflow like behavior <<<<<
    introduce_bufferoverflow_memory = False             # insert a value to overwrite the cpu "memory" for the current instruction set in the middle of program execution
    # >>>>> Set to True/False to enable buffer overflow like behavior <<<<<
    introduce_bufferoverflow_ProgramCounter = False     # insert a value to overwrite the "program counter" in the middle of program execution
    # >>>>> Set to various numeric values to simulate data which is "overflowing" <<<<<
    bufferoverflow_value = 999                          # overwite value to insert (try 999, try 899, try 200, try etc)
    # >>>>> Set this to a specific step/point in CPU execution of when "overflow" should happen <<<<<
    bufferoverflow_at = 140                             # execution step of when to introduce the simulated "buffer overflow"
    # Leave this alone
    bufferoverflow_counter = 0                          # Leave this alone, simply a counter doubling at a execution step counter 
    """ Runs code in memory until halt/reset opcode 900. 
    Leave the below alone, does not need to be modified"""
    pc=None
    if pc:
        c.pc = pc
    c.running = True
    
    while c.running:
        if(introduce_bufferoverflow_memory):  
            if(bufferoverflow_counter == bufferoverflow_at):
                Printer.printing("!!!!!!--\"buffer overflow\" introduced in program memory--!!!!!!!")
                c.mem[c.pc] = bufferoverflow_value
                    
        if(introduce_bufferoverflow_ProgramCounter):  
            if(bufferoverflow_counter == bufferoverflow_at):
                Printer.printing("!!!!!!--\"buffer overflow\" introduced in program counter--!!!!!!!")
                c.pc = bufferoverflow_value
     
        c.process() #do regular execution of CPU activity
        Printer.print_Memory(c, bufferoverflow_counter)
        bufferoverflow_counter = bufferoverflow_counter+1
    print ("\nCPU done processing -> Output:\n%s" % '\n'.join(c.output))
    c.init_output()

  
    
