# current unused - add this to some demo thing
#===============================================================================
# By Jason Tsang Mui Chung
# This file can largely be ignore, it is meant to suppliment "run.py" and provide tutorial information
# this is used to print explantions of what is happening, it does not alter functionality
# This script was written in python version 3.7.9, as such run it using python3
#===============================================================================

from visual_explanation import Printer 
#===============================================================================
# How does binary work??? 1s and 0s
# Power of 2       | (2^7) | (2^6) | (2^5) | (2^4) | (2^3) | (2^2) | (2^1) | (2^0) | 
# Binary Position  |   0   |   0   |   0   |   0   |   0   |   0   |   0   |   0   | (right to left)
# Decimal          |  128  |  64   |  32   |  16   |   8   |   4   |   2   |   1   |
# e.g: 101 = [(2^2) + _____ + (2^0)] = [4 + 0 + 1] = 5
# e.g: 010 = [_____ + (2^1) + _____] = [0 + 2 + 0] = 2
#
# Decimal: | 0 | 1 | 2  | 3  | 4   | 5   | 6   | 7   | 8    | 9    | 10
# Binary:  | 0 | 1 | 10 | 11 | 100 | 101 | 110 | 111 | 1000 | 1001 | 1010
#===============================================================================

def print_binary_explantion():
    print("Logical gates are operations such as \"OR\",\"AND\",etc - these boolean logic and also the functionality transistor provide")
    print("CPUs are a large collection of transitors, gates, on/off or true/false states. The first computers were state machines of combinations of on and off.")
    print("We represent states with 1s and 0s, '1' being 'true' and '0' being 'false'")
    print("from this we make binary and other higher logic from these basic concepts to represent more complicated forms of data and logic") 
    print(" How does binary work??? 1s and 0s")
    print(" Power of 2       | (2^7) | (2^6) | (2^5) | (2^4) | (2^3) | (2^2) | (2^1) | (2^0) | ")
    print(" Binary Position  |   0   |   0   |   0   |   0   |   0   |   0   |   0   |   0   | (right to left)")
    print(" Decimal          |  128  |  64   |  32   |  16   |   8   |   4   |   2   |   1   |")
    print(" e.g: 101 = [(2^2) + _____ + (2^0)] = [4 + 0 + 1] = 5")
    print(" e.g: 010 = [_____ + (2^1) + _____] = [0 + 2 + 0] = 2")
    print("")
    print(" Decimal: | 0 | 1 | 2  | 3  | 4   | 5   | 6   | 7   | 8    | 9    | 10")
    print(" Binary:  | 0 | 1 | 10 | 11 | 100 | 101 | 110 | 111 | 1000 | 1001 | 1010")
    print("---Now suppliment this with boolean logic and \"truth tables\"")
class Gates: 
    @staticmethod
    def OR(a, b):
        print_binary_explantion()
        print("a (OR) b \n"+str(a)+" (OR) " +str(b)+" ")
        Printer.print_OR(a, b) #This part is meant to print a visual explanation (not necessary to functionality)
        if a == 1 or b ==1:
            return True
        else:
            return False
    @staticmethod    
    def AND (a, b):
        print_binary_explantion()
        print("a (AND) b \n"+str(a)+" (AND) " +str(b)+" ")
        Printer.print_AND(a, b) #This part is meant to print a visual explanation (not necessary to functionality)
        if a == 1 and b == 1:
            # binary 1
            return True
        else:
            #binary 0
            return False