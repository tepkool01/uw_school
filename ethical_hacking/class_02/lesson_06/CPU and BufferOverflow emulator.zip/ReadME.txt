""""
(start with run.py - read it thoroughly, then play with it and run it.)
The turorial is meant for the code file to actively be read, modified in certain places, rerun, experimented with, read again, etc.

The point of the program is
1) emulate a very basic CPU to show how CPUs work, based on the CardiacCPU (cardboard computer)
2) allow a opportunity to simulate, experiment, and observe with a buffer overflow in this emulated CPU

any comments which look like this
# >>>>> do something <<<<<<
shows where the code file is meant for you to modify, interact with, and rerun. 
then go observe the difference in behavior, do some experimentation, etc

By: Jason Tsang Mui Chung
This script was written in python version 3.7.9, as such run it using python3
"""