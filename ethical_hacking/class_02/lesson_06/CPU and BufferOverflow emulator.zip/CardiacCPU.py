# This file can be left alone, its the code which emulates a Cardiac CPU
# Nothing wrong with analyzing or modifying it, however the main interface for this tutorial is from "run.py"
import os
import sys
import math 

#===============================================================================
# The code below was taken from http://www.pythondiary.com/blog/Oct.15,2014/building-run-simulator-python.html
# written by: Kevin Veroneau 
# as a example it is well structured, so was adopted
# This code was then modified a bit for explantion purposes by jason tsang mui chung
# (cardiac CPU explanation: https://www.cs.drexel.edu/~bls96/museum/cardiac.html) 
# 
#Instruction Set for cardiac CPU
# Opcode     Mnemonic     Operation
# 0            INP        Read a card into memory
# 1            CLA        Clear accumulator and add from memory (load)
# 2            ADD        Add from memory to accumulator
# 3            TAC        Test accumulator and jump if negative
# 4            SFT        Shift accumulator
# 5            OUT        Write memory location to output card
# 6            STO        Store accumulator to memory
# 7            SUB        Subtract memory from accumulator
# 8            JMP        Jump and save PC
# 9            HRS        Halt and reset
#
# Encoding of instruction 
# e.g: sampe instruction "205"
# |OpCode|  Address  |
# | 100s | 10s |  1s |
# |  2   |  0  |  5  |
# e.g: sampe instruction "205"
# |  2   |  0  |  5  |
#    ADD       05
#  Add from memory (location 05) to accumulator
#===============================================================================
class Cardiac(object):
    """
    This class is the cardiac "CPU", the cardboard computer.
    """
    def __init__(self):
        self.init_cpu()
        self.reset()
        self.init_mem()
        self.init_reader()
        self.init_output()
    def reset(self):
        """
        This method resets the CPU's registers to their defaults.
        """
        self.pc = 0 #: Program Counter
        self.ir = 0 #: Instruction Register
        self.acc = 0 #: Accumulator
        self.running = False #: Are we running?
    def init_cpu(self):
        """
        This fancy method will automatically build a list of our opcodes into a hash.
        This enables us to build a typical case/select system in Python and also keeps
        things more DRY.  We could have also used the getattr during the process()
        method before, and wrapped it around a try/except block, but that looks
        a bit messy.  This keeps things clean and simple with a nice one-to-one
        call-map. 
        """
        self.__opcodes = {}
        classes = [self.__class__] #: This holds all the classes and base classes.
        while classes:
            cls = classes.pop() # Pop the classes stack and being
            if cls.__bases__: # Does this class have any base classes?
                classes = classes + list(cls.__bases__)
            for name in dir(cls): # Lets iterate through the names.
                if name[:7] == 'opcode_': # We only want opcodes here.
                    try:
                        opcode = int(name[7:])
                    except ValueError:
                        raise NameError('Opcodes must be numeric, invalid opcode: %s' % name[7:])
                    self.__opcodes.update({opcode:getattr(self, 'opcode_%s' % opcode)})
    def init_mem(self):
        """
        This method resets the Cardiac's memory space to all blank strings, as per Cardiac specs.
        """
        #this is our memory (dependign on arcitecture our registers) 
        self.mem = ['' for i in range(0,100)]
        self.mem[0] = '001' #: The Cardiac bootstrap operation.
    def init_reader(self):
        """
        Thi sis our stack
        This method initializes the input reader.
        """
        self.reader = [] #: This variable can be accessed after initializing the class to provide input data.
    def init_output(self):
        """
        This method initializes the output deck/paper/printer/teletype/etc...
        """
        self.output = []
        
    def read_deck(self, fname):
        """
        This method will read a list of instructions into the reader.
        """
        self.reader = [s.rstrip('\n') for s in open(fname, 'r').readlines()]
        self.reader.reverse()
    def fetch(self):
        """
        This method retrieves an instruction from memory address pointed to by the program pointer.
        Then we increment the program pointer.
        """
        self.ir = int(self.mem[self.pc])
        self.pc +=1
    def get_memint(self, data):
        """
        Since our memory storage is *string* based, like the real Cardiac, we need
        a reusable function to grab a integer from memory.  This method could be
        overridden if say a new memory type was implemented, say an mmap one.
        """
        return int(self.mem[data])
    def pad(self, data, length=3):
        """
        This function pads either an integer or a number in string format with
        zeros.  This is needed to replicate the exact behavior of the Cardiac.
        """
        orig = int(data)
        padding = '0'*length
        data = '%s%s' % (padding, abs(data))
        if orig < 0:
            return '-'+data[-length:]
        return data[-length:]

    def process(self):
        """
        Process a single opcode from the current program counter.  This is
        normally called from the running loop, but can also be called
        manually to provide a "step-by-step" debugging interface, or
        to slow down execution using time.sleep().  This is the method
        that will also need to used if you build a TK/GTK/Qt/curses frontend
        to control execution in another thread of operation.
        """
        self.fetch()
        opcode, data = int(math.floor(self.ir / 100)), self.ir % 100
        self.__opcodes[opcode](data)
    def opcode_0(self, data):
        """ INPUT Operation """
        self.mem[data] = self.reader.pop()
    def opcode_1(self, data):
        """ Clear and Add Operation """
        self.acc = self.get_memint(data)
    def opcode_2(self, data):
        """ Add Operation """
        self.acc += self.get_memint(data)
    def opcode_3(self, data):
        """ Test Accumulator contents Operation """
        if self.acc < 0:
            self.pc = data
    def opcode_4(self, data):
        """ Shift operation """
        x,y = int(math.floor(data / 10)), int(data % 10)
        for i in range(0,x):
            self.acc = (self.acc * 10) % 10000
        for i in range(0,y):
            self.acc = int(math.floor(self.acc / 10))
    def opcode_5(self, data):
        """ Output operation """
        self.output.append(self.mem[data])
    def opcode_6(self, data):
        """ Store operation """
        self.mem[data] = self.pad(self.acc)
    def opcode_7(self, data):
        """ Subtract Operation """
        self.acc -= self.get_memint(data)
    def opcode_8(self, data):
        """ Unconditional Jump operation """
        self.pc = data
    def opcode_9(self, data):
        """ Halt and Reset operation """
        self.reset()
    
    def run(self, pc=None):
        #=======================================================================
        # Here we introducte a buffer overflow
        # 
        #=======================================================================
        introduce_bufferoverflow = False
        bufferoverflow_at = 10 # when to introduce the overflow
        bufferoverflow_counter = 0 # simply a counter 
        """ Runs code in memory until halt/reset opcode. """
        if pc:
            self.pc = pc
        self.running = True
        while self.running:
            if(introduce_bufferoverflow):
                bufferoverflow_counter = bufferoverflow_counter + 1
                if(bufferoverflow_counter >= bufferoverflow_at):
                    print("--overflow introduced--")
                    self.mem[bufferoverflow_at] = 505
            self.process()
        print ("Output:\n%s" % '\n'.join(self.output))
        self.init_output()


        
if __name__ == '__main__':
    c = Cardiac()
    c.read_deck(os.path.join(sys.path[0], "cpu_input.txt"))
    try:
        c.run()
    except:
        print ("IR: %s\nPC: %s\nOutput: %s\n" % (c.ir, c.pc, '\n'.join(c.output)))
        raise