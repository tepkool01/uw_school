# This file can be left alone, its the code which prints user friendly explantions while the CPU runs
# Nothing wrong with analyzing or modifying it, however the main interface for this tutorial is from "run.py"
import sys
#===============================================================================
# By Jason Tsang Mui Chung
# This file can largely be ignore, it is meant to suppliment "run.py" and provide tutorial information
# this is used to print explantions of what is happening, it does not alter functionality
# This script was written in python version 3.7.9, as such run it using python3
#===============================================================================

#this shows basic information of what data is in the CPU
Show_Visual_Explanations = True #>>>>> Set this to True or False to turn on/off all the extra print statements when running which explains whats going on <<<<<<<<
#This prints extra explanations of what is going on
Show_Tutorial = True #>>>>> Set this to True or False to turn on/off all the extra print statements when running which explains whats going on <<<<<<<<<<

open('log.txt', 'w').close()
OutputFile= "log.txt"
OF = open(OutputFile, 'w')

#prints to console + prints to log file
def printing(text):
    print(text)
    if(OutputFile):
        OF.write(text + "\n")

#helping to print multiple things on the same line
def print_no_newline(string):
    sys.stdout.write(string)
    if(OutputFile):
        OF.write(string)
    sys.stdout.flush()

# current unused - add this to some demo thing
def AND (a, b):
    if a == 1 and b == 1:
        # binary 1
        return True
    else:
        #binary 0
        return False
# current unused - add this to some demo thing
def OR(a, b):
    if a == 1 or b ==1:
        return True
    else:
        return False
 
def print_Cardiac_OpCode_Meaning(code):
    #Opcode     Mnemonic     Operation
    meaning=["Opcode","Mnemonic","Operation"]
    code = int(code)
    if(code == 0):
        meaning[0]="0" #Opcode
        meaning[1]="INP" #Mnemonic
        meaning[2]="Read a card into memory" #Operation
    if(code == 1):
        meaning[0]="1" #Opcode
        meaning[1]="CLA " #Mnemonic
        meaning[2]="Clear accumulator and add from memory (load)" #Operation
    if(code == 2):
        meaning[0]="2" #Opcode
        meaning[1]="ADD" #Mnemonic
        meaning[2]="Add from memory to accumulator" #Operation
    if(code == 3):
        meaning[0]="3" #Opcode
        meaning[1]="TAC " #Mnemonic
        meaning[2]="Test accumulator and jump if negative" #Operation
    if(code == 4):
        meaning[0]="4" #Opcode
        meaning[1]="SFT" #Mnemonic
        meaning[2]="Shift accumulator" #Operation
    if(code == 5):
        meaning[0]="5" #Opcode
        meaning[1]="OUT" #Mnemonic
        meaning[2]="Write memory location to output card" #Operation
    if(code == 6):
        meaning[0]="6" #Opcode
        meaning[1]="STO" #Mnemonic
        meaning[2]="Store accumulator to memory" #Operation
    if(code == 7):
        meaning[0]="7" #Opcode
        meaning[1]="SUB" #Mnemonic
        meaning[2]="Subtract memory from accumulator" #Operation
    if(code == 8):
        meaning[0]="8" #Opcode
        meaning[1]="JMP" #Mnemonic
        meaning[2]="Jump and save PC" #Operation
    if(code == 9):
        meaning[0]="9" #Opcode
        meaning[1]="HRS" #Mnemonic
        meaning[2]="Halt and reset" #Operation
    return meaning   

class Printer: 
    @staticmethod
    def printing(text):
        print(text)
        if(OutputFile):
            OF.write(text + "\n")
    @staticmethod
    def print_AND(a,b):
        #Truth table code from https://www.geeksforgeeks.org/logic-gates-in-python/ 
        if(Show_Visual_Explanations):
            print(AND(a, b))
            print("+---------Explantion of how Boolean 'AND' works-------------+")
            print(" | AND Truth Table | Result |")
            print("  A = False, B = False | A AND B =",AND(False,False)," | ")
            print("  A = False, B = True  | A AND B =",AND(False,True)," | ")
            print("  A = True,  B = False | A AND B =",AND(True,False)," | ")
            print("  A = True,  B = True  | A AND B =",AND(True,True)," | ")
    @staticmethod       
    def print_OR(a,b):
        #Truth table code from https://www.geeksforgeeks.org/logic-gates-in-python/ 
        if(Show_Visual_Explanations):
            print(OR(a, b))
            print("+---------Explantion of how Boolean 'OR' works--------------+")
            print(" | OR Truth Table | Result |")
            print("  A = False, B = False | A OR B =",OR(False,False)," | ")
            print("  A = False, B = True  | A OR B =",OR(False,True)," | ")
            print("  A = True,  B = False | A OR B =",OR(True,False)," | ")
            print("  A = True,  B = True  | A OR B =",OR(True,True)," | ")
    @staticmethod
    def print_MachineCode():
        # current unused - add this to some demo thing
        print("LOAD  R1, ADDRESS_Z //move the value of Z into register 1")
        print("MUL   R1, 3         //multiply the value of register 1 by 3")
        print("LOAD  R2, ADDRESS_Y //move the value of Y into register 2")
        print("ADD   R1, R2        //adds the value in R2 to the value in R1")
        print("STORE R1, ADDRESS_X //move the value of register 1 into X)")
    @staticmethod
    def print_stack(c):
        StackSize = len(c.reader)
        printing("--- stack ---")
        printing("stack size: " + str(StackSize) )
        print_no_newline("[") 
        for x in c.reader:
            print_no_newline(str(x) + " , ")
        printing ("]")  
        #print ("-----------")      print("{:02d}".format(1))
    @staticmethod
    def print_Memory(c, bufferoverflow_counter):
        printing ("-(step"+str(bufferoverflow_counter)+")--- Print What's in Memory -------------------------------------------")
        # c.ir is from the "fetch" function. 
        # fetch retrieves an instruction from memory address pointed to by the program pointer.
        # pc is the
        Current_Instruction_Register = str(c.ir).zfill(len(str(100)))
        opcode_meaning = print_Cardiac_OpCode_Meaning(Current_Instruction_Register[0])
        printing("| Instruction Register: " + Current_Instruction_Register + " -> Program Counter (pointer): "+ str(c.pc).zfill(len(str(100))) + " -> Accumulator: "+ str(c.acc))
        if(Show_Tutorial):
            printing("|  __________________      Address:   "+Current_Instruction_Register[1]+Current_Instruction_Register[2])
            printing("| |OpCode|  Address  |     Opcode:    "+opcode_meaning[0])
            printing("| | 100s | 10s |  1s |     Mnemonic:  "+opcode_meaning[1])
            printing("| |__"+Current_Instruction_Register[0]+"___|__"+Current_Instruction_Register[1]+"__|__"+Current_Instruction_Register[2]+"__|     Operation: "+opcode_meaning[2])
        print_no_newline("| Memory Contents[") 
        for x in c.mem:
            print_no_newline(str(x).zfill(len(str(100))) + " , ")
        printing ("]")   
        if(Show_Tutorial):
            printing("| Memory Position  0     1     2     3     4      5     6     7     8     9    10    11    12    13    14    15    16    17    18    19    20    21    22    23    24    25    26    27    28    29    30 ")
            printing("| Load Memory Position ('"+str(c.pc)+"') from current \"program counter\" > as \"instruction register\" for (step"+str(bufferoverflow_counter + 1)+")") 