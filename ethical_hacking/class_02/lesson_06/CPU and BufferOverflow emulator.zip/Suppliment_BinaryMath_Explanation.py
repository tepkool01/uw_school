# current unused - add this to some demo thing
#===============================================================================
# By Jason Tsang Mui Chung
# This file can largely be ignore, it is meant to suppliment "run.py" and provide tutorial information
# this is used to print explantions of what is happening, it does not alter functionality
# This script was written in python version 3.7.9, as such run it using python3
#===============================================================================


#===============================================================================
# Input:  a = "11", b = "1"
# Output: "100"
# 
# Input: a = "1101", b = "100"
# Output: 10001
#===============================================================================
class binarymath:
    @staticmethod
    def Add(data_A,data_B):
        # addition code from https://www.geeksforgeeks.org/python-program-to-add-two-binary-numbers/ 
        # code has been modified by for explantion purposes
        max_len = max(len(data_A), len(data_B)) 
        a = data_A.zfill(max_len) 
        b = data_B.zfill(max_len) 
          
        # Initialize the result 
        result = '' 
          
        # Initialize the carry 
        carry = 0
        
        #===============================================================================
        # Simple addition using binary, we can do math based on "binary position" and boolean logic
        # 
        # Traverse the string
        # (Boolean Logic here) for each "binary position" we do "Logical gates"/truth tables 
        # if we do a "OR" operation on each binary position, between two binary strings, the end result is addition.
        # e.g: 101 = [(2^2) + _____ + (2^0)] = [4 + 0 + 1] = 5
        # e.g: 010 = [_____ + (2^1) + _____] = [0 + 2 + 0] = 2
        #     | 1  | 0  | 1  |   !   | 1  | 0  | 0  |  
        #      (OR) (OR) (OR)    !    (OR) (OR) (OR)   
        #     | 0  | 1  | 0  |   !   | 1  | 1  | 0  |  
        #       =    =    =      !     =    =    =     
        #     | 1  | 1  | 1  |   !   | 1  | 1  | 0  |  
        #         111 = 7        !        110 = 6 
        #===============================================================================
        print(" Simple addition using binary, we can do math based on \"binary position\" and boolean logic")
        print(" ")
        print(" Traverse the string")
        print(" (Boolean Logic here) for each \"binary position\" we do \"Logical gates\"/truth tables ")
        print(" if we do a \"OR\" operation on each binary position, between two binary strings, the end result is addition.")
        print(" e.g: 101 = [(2^2) + _____ + (2^0)] = [4 + 0 + 1] = 5")
        print(" e.g: 010 = [_____ + (2^1) + _____] = [0 + 2 + 0] = 2")
        print("     | 1  | 0  | 1  |   !   | 1  | 0  | 0  |  ")
        print("      (OR) (OR) (OR)    !    (OR) (OR) (OR)   ")
        print("     | 0  | 1  | 0  |   !   | 1  | 1  | 0  |  ")
        print("       =    =    =      !     =    =    =     ")
        print("     | 1  | 1  | 1  |   !   | 1  | 1  | 0  |  ")
        print("         111 = 7        !        110 = 6 ")
        
        for i in range(max_len - 1, -1, -1): 
            r = carry 
            r += 1 if a[i] == '1' else 0
            r += 1 if b[i] == '1' else 0
            result = ('1' if r % 2 == 1 else '0') + result 
          
            # Compute the carry. 
            carry = 0 if r < 2 else 1
          
        if carry != 0: 
            result = '1' + result 
    
        result = result.zfill(max_len) 
        print('['+data_A+' -> '+str(int(data_A, 2)) +'] + ['+ data_B+' -> '+str(int(data_B, 2))+'] = '+ '['+result+' -> '+str(int(result, 2)) +']')
            
